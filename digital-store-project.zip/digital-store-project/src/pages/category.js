import React, { useState } from 'react';
import Head from 'next/head';

export default function CategoryPage() {
  const [sortBy, setSortBy] = useState('popular');
  const [viewMode, setViewMode] = useState('grid');
  
  // بيانات التصنيف (ستأتي من قاعدة البيانات لاحقاً)
  const category = {
    id: 'pubg-mobile',
    name: 'ببجي موبايل',
    description: 'جميع منتجات ببجي موبايل من شدات وعناصر داخل اللعبة بأفضل الأسعار وتسليم فوري',
    products: [
      { id: 'pubg-uc-60', name: 'شدات ببجي - 60 UC', price: 4.99, oldPrice: 5.99, discount: true },
      { id: 'pubg-uc-325', name: 'شدات ببجي - 325 UC', price: 19.99, oldPrice: 24.99, discount: true },
      { id: 'pubg-uc-660', name: 'شدات ببجي - 660 UC', price: 39.99, oldPrice: 45.99, discount: true },
      { id: 'pubg-uc-1800', name: 'شدات ببجي - 1800 UC', price: 99.99, oldPrice: 109.99, discount: true },
      { id: 'pubg-uc-3850', name: 'شدات ببجي - 3850 UC', price: 189.99, oldPrice: 199.99, discount: true },
      { id: 'pubg-uc-8100', name: 'شدات ببجي - 8100 UC', price: 379.99, oldPrice: 399.99, discount: true },
      { id: 'pubg-royal-pass', name: 'رويال باس ببجي', price: 129.99, oldPrice: 139.99, discount: true },
      { id: 'pubg-special-pack', name: 'باقة ببجي المميزة', price: 249.99, oldPrice: 279.99, discount: true }
    ],
    filters: [
      { id: 'price', name: 'السعر', options: ['أقل من 50 ريال', '50 - 100 ريال', '100 - 200 ريال', 'أكثر من 200 ريال'] },
      { id: 'type', name: 'النوع', options: ['شدات', 'رويال باس', 'باقات خاصة'] }
    ]
  };

  // التعامل مع تغيير طريقة الترتيب
  const handleSortChange = (e) => {
    setSortBy(e.target.value);
  };

  // ترتيب المنتجات حسب الاختيار
  const getSortedProducts = () => {
    switch (sortBy) {
      case 'price-asc':
        return [...category.products].sort((a, b) => a.price - b.price);
      case 'price-desc':
        return [...category.products].sort((a, b) => b.price - a.price);
      case 'newest':
        return category.products; // افتراضياً مرتبة حسب الأحدث
      case 'popular':
      default:
        return category.products; // افتراضياً مرتبة حسب الأكثر مبيعاً
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>{category.name} | متجر المنتجات الرقمية</title>
        <meta name="description" content={category.description} />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      {/* الهيدر (يمكن استخراجه كمكون منفصل) */}
      <header className="bg-primary-dark text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-cairo font-bold">متجر رقمي</h1>
          </div>
          <nav className="hidden md:flex space-x-reverse space-x-6">
            <a href="#" className="font-cairo hover:text-accent">الرئيسية</a>
            <a href="#" className="font-cairo hover:text-accent">المنتجات</a>
            <a href="#" className="font-cairo hover:text-accent">العروض</a>
            <a href="#" className="font-cairo hover:text-accent">اتصل بنا</a>
          </nav>
          <div className="flex items-center space-x-reverse space-x-4">
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </a>
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </a>
          </div>
        </div>
      </header>

      {/* مسار التنقل */}
      <div className="bg-white py-2 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm font-tajawal text-neutral">
            <a href="#" className="hover:text-primary">الرئيسية</a>
            <span className="mx-2">/</span>
            <a href="#" className="hover:text-primary">ألعاب</a>
            <span className="mx-2">/</span>
            <span className="text-neutral-dark">{category.name}</span>
          </div>
        </div>
      </div>

      {/* عنوان التصنيف */}
      <section className="py-6 bg-gradient-to-l from-primary-dark to-primary text-white">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-cairo font-bold">{category.name}</h1>
          <p className="font-tajawal mt-2">{category.description}</p>
        </div>
      </section>

      {/* محتوى الصفحة */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row">
            {/* الفلاتر الجانبية */}
            <div className="lg:w-1/4 mb-6 lg:mb-0 lg:ml-6">
              <div className="bg-white rounded-lg shadow-md p-4">
                <h2 className="text-xl font-cairo font-bold text-neutral-dark mb-4">تصفية النتائج</h2>
                
                {category.filters.map((filter) => (
                  <div key={filter.id} className="mb-6">
                    <h3 className="font-cairo font-bold text-neutral-dark mb-2">{filter.name}</h3>
                    <div className="space-y-2">
                      {filter.options.map((option, index) => (
                        <div key={index} className="flex items-center">
                          <input
                            type="checkbox"
                            id={`${filter.id}-${index}`}
                            className="ml-2 h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                          />
                          <label htmlFor={`${filter.id}-${index}`} className="font-tajawal text-neutral">
                            {option}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                
                <button className="w-full bg-primary hover:bg-primary-dark text-white font-cairo py-2 px-4 rounded-lg transition duration-300 mt-2">
                  تطبيق الفلتر
                </button>
              </div>
            </div>

            {/* قائمة المنتجات */}
            <div className="lg:w-3/4">
              {/* شريط الترتيب وطريقة العرض */}
              <div className="bg-white rounded-lg shadow-md p-4 mb-6 flex flex-col sm:flex-row justify-between items-center">
                <div className="mb-4 sm:mb-0 w-full sm:w-auto">
                  <label htmlFor="sort" className="font-cairo ml-2">ترتيب حسب:</label>
                  <select
                    id="sort"
                    value={sortBy}
                    onChange={handleSortChange}
                    className="border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  >
                    <option value="popular">الأكثر مبيعاً</option>
                    <option value="newest">الأحدث</option>
                    <option value="price-asc">السعر: من الأقل للأعلى</option>
                    <option value="price-desc">السعر: من الأعلى للأقل</option>
                  </select>
                </div>
                <div className="flex space-x-reverse space-x-2">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-primary-light text-primary-dark' : 'bg-gray-100 text-neutral'}`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-primary-light text-primary-dark' : 'bg-gray-100 text-neutral'}`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* عرض المنتجات */}
              {viewMode === 'grid' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {getSortedProducts().map((product) => (
                    <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition duration-300">
                      <div className="relative">
                        <div className="aspect-w-1 aspect-h-1 bg-gray-100">
                          {/* هنا ستكون صورة المنتج */}
                          <div className="flex items-center justify-center h-48">
                            <span className="text-gray-500 font-cairo">صورة المنتج</span>
                          </div>
                        </div>
                        {product.discount && (
                          <div className="absolute top-2 right-2 bg-error text-white text-xs font-cairo font-bold px-2 py-1 rounded">خصم</div>
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="font-cairo font-bold text-lg mb-2">{product.name}</h3>
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-cairo font-bold text-lg text-primary-dark">{product.price} ريال</span>
                            {product.oldPrice && (
                              <span className="text-neutral line-through mr-2 text-sm">{product.oldPrice} ريال</span>
                            )}
                          </div>
                          <button className="bg-primary hover:bg-primary-dark text-white font-cairo py-1 px-3 rounded-lg text-sm transition duration-300">شراء</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {getSortedProducts().map((product) => (
                    <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition duration-300">
                      <div className="flex flex-col sm:flex-row">
                        <div className="sm:w-1/4 relative">
                          <div className="aspect-w-1 aspect-h-1 bg-gray-100 h-full">
                            {/* هنا ستكون صورة المنتج */}
                            <div className="flex items-center justify-center h-full">
                              <span className="text-gray-500 font-cairo">صورة المنتج</span>
                            </div>
                          </div>
                          {product.discount && (
                            <div className="absolute top-2 right-2 bg-error text-white text-xs font-cairo font-bold px-2 py-1 rounded">خصم</div>
                          )}
                        </div>
                        <div className="sm:w-3/4 p-4 flex flex-col justify-between">
                          <div>
                            <h3 className="font-cairo font-bold text-lg mb-2">{product.name}</h3>
                            <p className="font-tajawal text-neutral mb-4">وصف مختصر للمنتج يظهر فقط في طريقة عرض القائمة</p>
                          </div>
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="font-cairo font-bold text-lg text-primary-dark">{product.price} ريال</span>
                              {product.oldPrice && (
                                <span className="text-neutral line-through mr-2 text-sm">{product.oldPrice} ريال</span>
                              )}
                            </div>
                            <div className="flex space-x-reverse space-x-2">
                              <button className="bg-gray-100 hover:bg-gray-200 text-neutral-dark font-cairo py-2 px-4 rounded-lg text-sm transition duration-300">إضافة للسلة</button>
                              <button className="bg-primary hover:bg-primary-dark text-white font-cairo py-2 px-4 rounded-lg text-sm transition duration-300">شراء الآن</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* ترقيم الصفحات */}
              <div className="mt-8 flex justify-center">
                <nav className="flex items-center space-x-reverse space-x-1">
                  <a href="#" className="px-3 py-2 rounded-lg border border-gray-300 text-neutral-dark font-cairo hover:bg-gray-100">السابق</a>
                  <a href="#" className="px-3 py-2 rounded-lg bg-primary text-white font-cairo">1</a>
                  <a href="#" className="px-3 py-2 rounded-lg border border-gray-300 text-neutral-dark font-cairo hover:bg-gray-100">2</a>
                  <a href="#" className="px-3 py-2 rounded-lg border border-gray-300 text-neutral-dark font-cairo hover:bg-gray-100">3</a>
                  <span className="px-3 py-2 text-neutral-dark font-cairo">...</span>
                  <a href="#" className="px-3 py-2 rounded-lg border border-gray-300 text-neutral-dark font-cairo hover:bg-gray-100">10</a>
                  <a href="#" className="px-3 py-2 rounded-lg border border-gray-300 text-neutral-dark font-cairo hover:bg-gray-100">التالي</a>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* الفوتر (يمكن استخراجه كمكون منفصل) */}
      <footer className="bg-primary-dark text-white py-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">متجر رقمي</h3>
              <p className="font-tajawal mb-4">متجرك الأول للمنتجات الرقمية بأفضل الأسعار وتسليم فوري</p>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">روابط سريعة</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الرئيسية</a></li>
                <li><a href="#" className="hover:text-accent">المنتجات</a></li>
                <li><a href="#" className="hover:text-accent">العروض</a></li>
                <li><a href="#" className="hover:text-accent">من نحن</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">خدمة العملاء</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-accent">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent">شروط الاستخدام</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">اتصل بنا</h3>
              <ul className="font-tajawal space-y-2">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>info@digitalstore.com</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span>+966 55 1234567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center">
            <p className="font-tajawal">جميع الحقوق محفوظة © {new Date().getFullYear()} متجر رقمي</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
