import React, { useState } from 'react';
import Head from 'next/head';

export default function ProductPage() {
  const [quantity, setQuantity] = useState(1);
  const [selectedOption, setSelectedOption] = useState('option1');
  
  // بيانات المنتج (ستأتي من قاعدة البيانات لاحقاً)
  const product = {
    id: 'pubg-uc-660',
    name: 'شدات ببجي - 660 UC',
    price: 39.99,
    oldPrice: 45.99,
    description: 'شدات ببجي موبايل (UC) هي العملة الافتراضية داخل لعبة ببجي موبايل، يمكنك استخدامها لشراء الأزياء والإكسسوارات والعناصر المختلفة داخل اللعبة.',
    options: [
      { id: 'option1', name: '660 UC', price: 39.99, oldPrice: 45.99 },
      { id: 'option2', name: '1800 UC', price: 99.99, oldPrice: 109.99 },
      { id: 'option3', name: '3850 UC', price: 189.99, oldPrice: 199.99 },
      { id: 'option4', name: '8100 UC', price: 379.99, oldPrice: 399.99 }
    ],
    instructions: [
      'قم بتسجيل الدخول إلى حساب ببجي موبايل الخاص بك',
      'انتقل إلى متجر اللعبة',
      'اختر "استبدال القسيمة" أو "Redeem Code"',
      'أدخل الكود الذي ستحصل عليه بعد إتمام عملية الشراء',
      'ستضاف الشدات إلى حسابك فوراً'
    ],
    rating: 4.8,
    reviewCount: 156
  };

  // التعامل مع تغيير الكمية
  const handleQuantityChange = (e) => {
    const value = parseInt(e.target.value);
    if (value > 0) {
      setQuantity(value);
    }
  };

  // التعامل مع تغيير الخيار
  const handleOptionChange = (optionId) => {
    setSelectedOption(optionId);
  };

  // الحصول على السعر الحالي بناءً على الخيار المحدد
  const getCurrentPrice = () => {
    const option = product.options.find(opt => opt.id === selectedOption);
    return option ? option.price : product.price;
  };

  // الحصول على السعر القديم بناءً على الخيار المحدد
  const getOldPrice = () => {
    const option = product.options.find(opt => opt.id === selectedOption);
    return option ? option.oldPrice : product.oldPrice;
  };

  // حساب السعر الإجمالي
  const getTotalPrice = () => {
    return (getCurrentPrice() * quantity).toFixed(2);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>{product.name} | متجر المنتجات الرقمية</title>
        <meta name="description" content={product.description.substring(0, 160)} />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      {/* الهيدر (يمكن استخراجه كمكون منفصل) */}
      <header className="bg-primary-dark text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-cairo font-bold">متجر رقمي</h1>
          </div>
          <nav className="hidden md:flex space-x-reverse space-x-6">
            <a href="#" className="font-cairo hover:text-accent">الرئيسية</a>
            <a href="#" className="font-cairo hover:text-accent">المنتجات</a>
            <a href="#" className="font-cairo hover:text-accent">العروض</a>
            <a href="#" className="font-cairo hover:text-accent">اتصل بنا</a>
          </nav>
          <div className="flex items-center space-x-reverse space-x-4">
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </a>
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </a>
          </div>
        </div>
      </header>

      {/* مسار التنقل */}
      <div className="bg-white py-2 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm font-tajawal text-neutral">
            <a href="#" className="hover:text-primary">الرئيسية</a>
            <span className="mx-2">/</span>
            <a href="#" className="hover:text-primary">ألعاب</a>
            <span className="mx-2">/</span>
            <a href="#" className="hover:text-primary">ببجي موبايل</a>
            <span className="mx-2">/</span>
            <span className="text-neutral-dark">{product.name}</span>
          </div>
        </div>
      </div>

      {/* تفاصيل المنتج */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="flex flex-col md:flex-row">
              {/* صورة المنتج */}
              <div className="md:w-1/2 p-6">
                <div className="bg-gray-100 rounded-lg p-4 flex items-center justify-center h-80">
                  {/* هنا ستكون صورة المنتج */}
                  <div className="text-center">
                    <span className="text-gray-500 font-cairo text-lg">صورة {product.name}</span>
                  </div>
                </div>
              </div>

              {/* معلومات المنتج */}
              <div className="md:w-1/2 p-6">
                <h1 className="text-2xl font-cairo font-bold text-neutral-dark mb-2">{product.name}</h1>
                
                {/* التقييم */}
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <svg key={star} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill={star <= Math.floor(product.rating) ? 'currentColor' : 'none'}>
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                  <span className="text-sm font-tajawal text-neutral mr-2">{product.rating} ({product.reviewCount} تقييم)</span>
                </div>

                {/* الوصف */}
                <p className="font-tajawal text-neutral mb-6">{product.description}</p>

                {/* الأسعار */}
                <div className="mb-6">
                  <div className="flex items-center">
                    <span className="font-cairo font-bold text-2xl text-primary-dark">{getCurrentPrice()} ريال</span>
                    <span className="text-neutral line-through mr-3 text-lg">{getOldPrice()} ريال</span>
                    <span className="bg-error text-white text-xs font-cairo font-bold px-2 py-1 rounded mr-3">خصم {Math.round(((getOldPrice() - getCurrentPrice()) / getOldPrice()) * 100)}%</span>
                  </div>
                  <p className="text-success text-sm font-tajawal mt-1">متوفر</p>
                </div>

                {/* خيارات المنتج */}
                <div className="mb-6">
                  <h3 className="font-cairo font-bold text-neutral-dark mb-2">اختر الكمية:</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {product.options.map((option) => (
                      <button
                        key={option.id}
                        className={`border rounded-lg py-2 px-3 font-cairo text-sm transition duration-200 ${
                          selectedOption === option.id
                            ? 'border-primary bg-primary-light text-primary-dark'
                            : 'border-gray-300 hover:border-primary'
                        }`}
                        onClick={() => handleOptionChange(option.id)}
                      >
                        {option.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* الكمية */}
                <div className="mb-6">
                  <h3 className="font-cairo font-bold text-neutral-dark mb-2">الكمية:</h3>
                  <div className="flex items-center">
                    <button
                      className="bg-gray-200 text-neutral-dark rounded-r-lg px-3 py-1"
                      onClick={() => quantity > 1 && setQuantity(quantity - 1)}
                    >
                      -
                    </button>
                    <input
                      type="number"
                      min="1"
                      value={quantity}
                      onChange={handleQuantityChange}
                      className="w-16 text-center border-t border-b border-gray-200 py-1 font-cairo"
                    />
                    <button
                      className="bg-gray-200 text-neutral-dark rounded-l-lg px-3 py-1"
                      onClick={() => setQuantity(quantity + 1)}
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* السعر الإجمالي */}
                <div className="mb-6 p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-center">
                    <span className="font-cairo">السعر الإجمالي:</span>
                    <span className="font-cairo font-bold text-xl text-primary-dark">{getTotalPrice()} ريال</span>
                  </div>
                </div>

                {/* أزرار الشراء */}
                <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-reverse sm:space-x-3">
                  <button className="bg-primary hover:bg-primary-dark text-white font-cairo font-bold py-3 px-6 rounded-lg transition duration-300 flex-1 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                    إضافة للسلة
                  </button>
                  <button className="bg-accent hover:bg-yellow-500 text-primary-dark font-cairo font-bold py-3 px-6 rounded-lg transition duration-300 flex-1">
                    شراء الآن
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* تفاصيل إضافية */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="border-b">
              <div className="flex">
                <button className="px-6 py-3 font-cairo font-bold text-primary-dark border-b-2 border-primary">تفاصيل المنتج</button>
                <button className="px-6 py-3 font-cairo text-neutral hover:text-primary-dark">تعليمات الاستخدام</button>
                <button className="px-6 py-3 font-cairo text-neutral hover:text-primary-dark">التقييمات</button>
              </div>
            </div>
            <div className="p-6">
              <h2 className="text-xl font-cairo font-bold text-neutral-dark mb-4">وصف المنتج</h2>
              <p className="font-tajawal text-neutral mb-6">{product.description}</p>
              
              <h3 className="text-lg font-cairo font-bold text-neutral-dark mb-3">تعليمات الاستخدام:</h3>
              <ul className="list-decimal pr-5 font-tajawal text-neutral space-y-2">
                {product.instructions.map((instruction, index) => (
                  <li key={index}>{instruction}</li>
                ))}
              </ul>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
                <div className="flex items-start">
                  <div className="bg-primary-light text-primary-dark rounded-full p-2 ml-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-cairo font-bold text-neutral-dark mb-1">ملاحظة هامة</h4>
                    <p className="font-tajawal text-neutral">يرجى التأكد من إدخال الكود بشكل صحيح. الكود صالح لمدة 30 يوماً من تاريخ الشراء. في حال واجهتك أي مشكلة، يرجى التواصل مع خدمة العملاء.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* منتجات ذات صلة */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-cairo font-bold text-neutral-dark mb-6">منتجات ذات صلة</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { name: 'شدات ببجي - 325 UC', price: '19.99', oldPrice: '24.99' },
              { name: 'شدات ببجي - 1800 UC', price: '99.99', oldPrice: '109.99' },
              { name: 'رويال باس ببجي', price: '129.99', oldPrice: '139.99' },
              { name: 'بطاقة Google Play - 10$', price: '39.99', oldPrice: '42.99' }
            ].map((relatedProduct, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition duration-300">
                <div className="relative">
                  <div className="aspect-w-1 aspect-h-1 bg-gray-100">
                    {/* هنا ستكون صورة المنتج */}
                    <div className="flex items-center justify-center h-48">
                      <span className="text-gray-500 font-cairo">صورة المنتج</span>
                    </div>
                  </div>
                  <div className="absolute top-2 right-2 bg-error text-white text-xs font-cairo font-bold px-2 py-1 rounded">خصم</div>
                </div>
                <div className="p-4">
                  <h3 className="font-cairo font-bold text-lg mb-2">{relatedProduct.name}</h3>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-cairo font-bold text-lg text-primary-dark">{relatedProduct.price} ريال</span>
                      <span className="text-neutral line-through mr-2 text-sm">{relatedProduct.oldPrice} ريال</span>
                    </div>
                    <button className="bg-primary hover:bg-primary-dark text-white font-cairo py-1 px-3 rounded-lg text-sm transition duration-300">شراء</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* الفوتر (يمكن استخراجه كمكون منفصل) */}
      <footer className="bg-primary-dark text-white py-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">متجر رقمي</h3>
              <p className="font-tajawal mb-4">متجرك الأول للمنتجات الرقمية بأفضل الأسعار وتسليم فوري</p>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">روابط سريعة</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الرئيسية</a></li>
                <li><a href="#" className="hover:text-accent">المنتجات</a></li>
                <li><a href="#" className="hover:text-accent">العروض</a></li>
                <li><a href="#" className="hover:text-accent">من نحن</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">خدمة العملاء</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-accent">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent">شروط الاستخدام</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">اتصل بنا</h3>
              <ul className="font-tajawal space-y-2">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>info@digitalstore.com</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span>+966 55 1234567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center">
            <p className="font-tajawal">جميع الحقوق محفوظة © {new Date().getFullYear()} متجر رقمي</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
