import React, { useState } from 'react';
import Head from 'next/head';

export default function CartPage() {
  // بيانات السلة (ستأتي من سياق السلة لاحقاً)
  const [cartItems, setCartItems] = useState([
    {
      id: 'pubg-uc-660',
      name: 'شدات ببجي - 660 UC',
      price: 39.99,
      quantity: 1,
      image: '/placeholder.jpg'
    },
    {
      id: 'google-play-50',
      name: 'بطاقة Google Play - 50$',
      price: 189.99,
      quantity: 1,
      image: '/placeholder.jpg'
    }
  ]);
  
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [discount, setDiscount] = useState(0);
  
  // تغيير كمية المنتج
  const updateQuantity = (id, newQuantity) => {
    if (newQuantity < 1) return;
    
    setCartItems(cartItems.map(item => 
      item.id === id ? { ...item, quantity: newQuantity } : item
    ));
  };
  
  // حذف منتج من السلة
  const removeItem = (id) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };
  
  // تطبيق كوبون الخصم
  const applyCoupon = () => {
    if (couponCode.toLowerCase() === 'welcome10') {
      setCouponApplied(true);
      setDiscount(getSubtotal() * 0.1); // خصم 10%
    } else {
      alert('كود الخصم غير صالح');
    }
  };
  
  // حساب المجموع الفرعي
  const getSubtotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };
  
  // حساب المجموع النهائي
  const getTotal = () => {
    return getSubtotal() - discount;
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>سلة التسوق | متجر المنتجات الرقمية</title>
        <meta name="description" content="سلة التسوق الخاصة بك في متجر المنتجات الرقمية" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      {/* الهيدر (يمكن استخراجه كمكون منفصل) */}
      <header className="bg-primary-dark text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-cairo font-bold">متجر رقمي</h1>
          </div>
          <nav className="hidden md:flex space-x-reverse space-x-6">
            <a href="#" className="font-cairo hover:text-accent">الرئيسية</a>
            <a href="#" className="font-cairo hover:text-accent">المنتجات</a>
            <a href="#" className="font-cairo hover:text-accent">العروض</a>
            <a href="#" className="font-cairo hover:text-accent">اتصل بنا</a>
          </nav>
          <div className="flex items-center space-x-reverse space-x-4">
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </a>
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </a>
          </div>
        </div>
      </header>

      {/* مسار التنقل */}
      <div className="bg-white py-2 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm font-tajawal text-neutral">
            <a href="#" className="hover:text-primary">الرئيسية</a>
            <span className="mx-2">/</span>
            <span className="text-neutral-dark">سلة التسوق</span>
          </div>
        </div>
      </div>

      {/* عنوان الصفحة */}
      <section className="py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-cairo font-bold text-neutral-dark">سلة التسوق</h1>
        </div>
      </section>

      {/* محتوى السلة */}
      <section className="py-6">
        <div className="container mx-auto px-4">
          {cartItems.length > 0 ? (
            <div className="flex flex-col lg:flex-row gap-6">
              {/* قائمة المنتجات */}
              <div className="lg:w-2/3">
                <div className="bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="p-4 border-b">
                    <h2 className="text-xl font-cairo font-bold text-neutral-dark">المنتجات ({cartItems.length})</h2>
                  </div>
                  
                  {/* المنتجات */}
                  <div className="divide-y">
                    {cartItems.map((item) => (
                      <div key={item.id} className="p-4 flex flex-col sm:flex-row items-center">
                        {/* صورة المنتج */}
                        <div className="sm:w-1/6 mb-4 sm:mb-0">
                          <div className="bg-gray-100 rounded-lg w-20 h-20 flex items-center justify-center">
                            <span className="text-gray-500 font-cairo text-xs">صورة المنتج</span>
                          </div>
                        </div>
                        
                        {/* تفاصيل المنتج */}
                        <div className="sm:w-2/6 mb-4 sm:mb-0 text-center sm:text-right">
                          <h3 className="font-cairo font-bold text-neutral-dark">{item.name}</h3>
                          <p className="text-sm font-tajawal text-neutral">كود رقمي</p>
                        </div>
                        
                        {/* الكمية */}
                        <div className="sm:w-1/6 mb-4 sm:mb-0 flex justify-center">
                          <div className="flex items-center">
                            <button
                              className="bg-gray-200 text-neutral-dark rounded-r-lg px-3 py-1"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            >
                              -
                            </button>
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                              className="w-12 text-center border-t border-b border-gray-200 py-1 font-cairo"
                            />
                            <button
                              className="bg-gray-200 text-neutral-dark rounded-l-lg px-3 py-1"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              +
                            </button>
                          </div>
                        </div>
                        
                        {/* السعر */}
                        <div className="sm:w-1/6 mb-4 sm:mb-0 text-center">
                          <span className="font-cairo font-bold text-primary-dark">{item.price} ريال</span>
                        </div>
                        
                        {/* المجموع */}
                        <div className="sm:w-1/6 mb-4 sm:mb-0 text-center">
                          <span className="font-cairo font-bold text-neutral-dark">{(item.price * item.quantity).toFixed(2)} ريال</span>
                        </div>
                        
                        {/* حذف */}
                        <div className="sm:w-1/12 text-center">
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-neutral hover:text-error transition duration-200"
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* زر متابعة التسوق */}
                  <div className="p-4 border-t">
                    <a href="#" className="inline-flex items-center font-cairo text-primary hover:text-primary-dark transition duration-200">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                      </svg>
                      متابعة التسوق
                    </a>
                  </div>
                </div>
              </div>
              
              {/* ملخص الطلب */}
              <div className="lg:w-1/3">
                <div className="bg-white rounded-lg shadow-md overflow-hidden">
                  <div className="p-4 border-b">
                    <h2 className="text-xl font-cairo font-bold text-neutral-dark">ملخص الطلب</h2>
                  </div>
                  
                  <div className="p-4">
                    {/* كوبون الخصم */}
                    <div className="mb-6">
                      <label htmlFor="coupon" className="block font-cairo font-bold text-neutral-dark mb-2">كوبون الخصم</label>
                      <div className="flex">
                        <input
                          type="text"
                          id="coupon"
                          value={couponCode}
                          onChange={(e) => setCouponCode(e.target.value)}
                          disabled={couponApplied}
                          placeholder="أدخل كود الخصم"
                          className="flex-1 border border-gray-300 rounded-r-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        />
                        <button
                          onClick={applyCoupon}
                          disabled={couponApplied}
                          className={`bg-primary hover:bg-primary-dark text-white font-cairo py-2 px-4 rounded-l-lg transition duration-300 ${couponApplied ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                          تطبيق
                        </button>
                      </div>
                      {couponApplied && (
                        <p className="text-success text-sm mt-1 font-tajawal">تم تطبيق الخصم بنجاح!</p>
                      )}
                    </div>
                    
                    {/* تفاصيل الدفع */}
                    <div className="space-y-3 mb-6">
                      <div className="flex justify-between">
                        <span className="font-tajawal text-neutral">المجموع الفرعي:</span>
                        <span className="font-cairo font-bold text-neutral-dark">{getSubtotal().toFixed(2)} ريال</span>
                      </div>
                      {couponApplied && (
                        <div className="flex justify-between text-success">
                          <span className="font-tajawal">الخصم:</span>
                          <span className="font-cairo font-bold">- {discount.toFixed(2)} ريال</span>
                        </div>
                      )}
                      <div className="border-t pt-3 flex justify-between">
                        <span className="font-cairo font-bold text-neutral-dark">المجموع:</span>
                        <span className="font-cairo font-bold text-primary-dark text-xl">{getTotal().toFixed(2)} ريال</span>
                      </div>
                    </div>
                    
                    {/* زر إتمام الطلب */}
                    <button className="w-full bg-accent hover:bg-yellow-500 text-primary-dark font-cairo font-bold py-3 px-6 rounded-lg transition duration-300 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                      </svg>
                      متابعة للدفع
                    </button>
                  </div>
                </div>
                
                {/* وسائل الدفع */}
                <div className="mt-4 bg-white rounded-lg shadow-md p-4">
                  <h3 className="font-cairo font-bold text-neutral-dark mb-3">وسائل الدفع المدعومة</h3>
                  <div className="flex flex-wrap gap-2">
                    <div className="bg-gray-100 rounded p-2 w-16 h-10 flex items-center justify-center">
                      <span className="text-xs font-cairo">Visa</span>
                    </div>
                    <div className="bg-gray-100 rounded p-2 w-16 h-10 flex items-center justify-center">
                      <span className="text-xs font-cairo">Mastercard</span>
                    </div>
                    <div className="bg-gray-100 rounded p-2 w-16 h-10 flex items-center justify-center">
                      <span className="text-xs font-cairo">مدى</span>
                    </div>
                    <div className="bg-gray-100 rounded p-2 w-16 h-10 flex items-center justify-center">
                      <span className="text-xs font-cairo">STC Pay</span>
                    </div>
                    <div className="bg-gray-100 rounded p-2 w-16 h-10 flex items-center justify-center">
                      <span className="text-xs font-cairo">Apple Pay</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="text-neutral mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h2 className="text-2xl font-cairo font-bold text-neutral-dark mb-2">سلة التسوق فارغة</h2>
              <p className="font-tajawal text-neutral mb-6">لم تقم بإضافة أي منتجات إلى سلة التسوق بعد.</p>
              <a href="#" className="bg-primary hover:bg-primary-dark text-white font-cairo font-bold py-2 px-6 rounded-lg transition duration-300">
                تصفح المنتجات
              </a>
            </div>
          )}
        </div>
      </section>

      {/* الفوتر (يمكن استخراجه كمكون منفصل) */}
      <footer className="bg-primary-dark text-white py-10 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">متجر رقمي</h3>
              <p className="font-tajawal mb-4">متجرك الأول للمنتجات الرقمية بأفضل الأسعار وتسليم فوري</p>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">روابط سريعة</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الرئيسية</a></li>
                <li><a href="#" className="hover:text-accent">المنتجات</a></li>
                <li><a href="#" className="hover:text-accent">العروض</a></li>
                <li><a href="#" className="hover:text-accent">من نحن</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">خدمة العملاء</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-accent">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent">شروط الاستخدام</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">اتصل بنا</h3>
              <ul className="font-tajawal space-y-2">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>info@digitalstore.com</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span>+966 55 1234567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center">
            <p className="font-tajawal">جميع الحقوق محفوظة © {new Date().getFullYear()} متجر رقمي</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
