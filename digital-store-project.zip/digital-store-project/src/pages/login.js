import React, { useState } from 'react';
import Head from 'next/head';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });
  
  // التعامل مع تغيير بيانات النموذج
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // التبديل بين تسجيل الدخول وإنشاء حساب
  const toggleForm = () => {
    setIsLogin(!isLogin);
  };
  
  // التعامل مع تقديم النموذج
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (isLogin) {
      // منطق تسجيل الدخول
      console.log('تسجيل الدخول:', {
        email: formData.email,
        password: formData.password
      });
      
      // في التطبيق الحقيقي، سيتم إرسال بيانات تسجيل الدخول إلى Firebase
      alert('تم تسجيل الدخول بنجاح!');
    } else {
      // التحقق من تطابق كلمات المرور
      if (formData.password !== formData.confirmPassword) {
        alert('كلمات المرور غير متطابقة');
        return;
      }
      
      // منطق إنشاء حساب جديد
      console.log('إنشاء حساب:', {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        password: formData.password
      });
      
      // في التطبيق الحقيقي، سيتم إرسال بيانات التسجيل إلى Firebase
      alert('تم إنشاء الحساب بنجاح!');
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>{isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'} | متجر المنتجات الرقمية</title>
        <meta name="description" content={isLogin ? 'تسجيل الدخول إلى حسابك' : 'إنشاء حساب جديد في متجر المنتجات الرقمية'} />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      {/* الهيدر (يمكن استخراجه كمكون منفصل) */}
      <header className="bg-primary-dark text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-cairo font-bold">متجر رقمي</h1>
          </div>
          <nav className="hidden md:flex space-x-reverse space-x-6">
            <a href="#" className="font-cairo hover:text-accent">الرئيسية</a>
            <a href="#" className="font-cairo hover:text-accent">المنتجات</a>
            <a href="#" className="font-cairo hover:text-accent">العروض</a>
            <a href="#" className="font-cairo hover:text-accent">اتصل بنا</a>
          </nav>
          <div className="flex items-center space-x-reverse space-x-4">
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </a>
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </a>
          </div>
        </div>
      </header>

      {/* مسار التنقل */}
      <div className="bg-white py-2 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm font-tajawal text-neutral">
            <a href="#" className="hover:text-primary">الرئيسية</a>
            <span className="mx-2">/</span>
            <span className="text-neutral-dark">{isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'}</span>
          </div>
        </div>
      </div>

      {/* محتوى الصفحة */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h1 className="text-2xl font-cairo font-bold text-neutral-dark text-center mb-6">
                {isLogin ? 'تسجيل الدخول إلى حسابك' : 'إنشاء حساب جديد'}
              </h1>
              
              <form onSubmit={handleSubmit}>
                {!isLogin && (
                  <div className="mb-4">
                    <label htmlFor="name" className="block font-cairo font-bold text-neutral-dark mb-2">الاسم الكامل</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      required
                    />
                  </div>
                )}
                
                <div className="mb-4">
                  <label htmlFor="email" className="block font-cairo font-bold text-neutral-dark mb-2">البريد الإلكتروني</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    required
                  />
                </div>
                
                {!isLogin && (
                  <div className="mb-4">
                    <label htmlFor="phone" className="block font-cairo font-bold text-neutral-dark mb-2">رقم الجوال</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      required
                    />
                  </div>
                )}
                
                <div className="mb-4">
                  <label htmlFor="password" className="block font-cairo font-bold text-neutral-dark mb-2">كلمة المرور</label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    required
                  />
                </div>
                
                {!isLogin && (
                  <div className="mb-6">
                    <label htmlFor="confirmPassword" className="block font-cairo font-bold text-neutral-dark mb-2">تأكيد كلمة المرور</label>
                    <input
                      type="password"
                      id="confirmPassword"
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      required
                    />
                  </div>
                )}
                
                {isLogin && (
                  <div className="mb-6 flex justify-end">
                    <a href="#" className="font-tajawal text-primary hover:text-primary-dark transition duration-200">
                      نسيت كلمة المرور؟
                    </a>
                  </div>
                )}
                
                <button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary-dark text-white font-cairo font-bold py-3 px-6 rounded-lg transition duration-300"
                >
                  {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'}
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="font-tajawal text-neutral">
                  {isLogin ? 'ليس لديك حساب؟' : 'لديك حساب بالفعل؟'}
                  <button
                    type="button"
                    onClick={toggleForm}
                    className="mr-1 font-cairo text-primary hover:text-primary-dark transition duration-200"
                  >
                    {isLogin ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}
                  </button>
                </p>
              </div>
              
              {isLogin && (
                <div className="mt-8 pt-6 border-t">
                  <p className="font-tajawal text-neutral text-center mb-4">أو تسجيل الدخول باستخدام</p>
                  <div className="flex justify-center space-x-reverse space-x-4">
                    <button className="bg-blue-600 hover:bg-blue-700 text-white font-cairo py-2 px-4 rounded-lg transition duration-300">
                      فيسبوك
                    </button>
                    <button className="bg-red-600 hover:bg-red-700 text-white font-cairo py-2 px-4 rounded-lg transition duration-300">
                      جوجل
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* الفوتر (يمكن استخراجه كمكون منفصل) */}
      <footer className="bg-primary-dark text-white py-10 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">متجر رقمي</h3>
              <p className="font-tajawal mb-4">متجرك الأول للمنتجات الرقمية بأفضل الأسعار وتسليم فوري</p>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">روابط سريعة</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الرئيسية</a></li>
                <li><a href="#" className="hover:text-accent">المنتجات</a></li>
                <li><a href="#" className="hover:text-accent">العروض</a></li>
                <li><a href="#" className="hover:text-accent">من نحن</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">خدمة العملاء</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-accent">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent">شروط الاستخدام</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">اتصل بنا</h3>
              <ul className="font-tajawal space-y-2">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>info@digitalstore.com</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span>+966 55 1234567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center">
            <p className="font-tajawal">جميع الحقوق محفوظة © {new Date().getFullYear()} متجر رقمي</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
