import React, { useState } from 'react';
import Head from 'next/head';

export default function CheckoutPage() {
  // بيانات الطلب (ستأتي من سياق السلة لاحقاً)
  const [orderItems] = useState([
    {
      id: 'pubg-uc-660',
      name: 'شدات ببجي - 660 UC',
      price: 39.99,
      quantity: 1
    },
    {
      id: 'google-play-50',
      name: 'بطاقة Google Play - 50$',
      price: 189.99,
      quantity: 1
    }
  ]);
  
  // بيانات العميل
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    email: '',
    phone: ''
  });
  
  // طريقة الدفع المختارة
  const [paymentMethod, setPaymentMethod] = useState('visa');
  
  // حالة الموافقة على الشروط
  const [termsAccepted, setTermsAccepted] = useState(false);
  
  // حساب المجموع
  const getSubtotal = () => {
    return orderItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };
  
  // التعامل مع تغيير بيانات العميل
  const handleCustomerInfoChange = (e) => {
    const { name, value } = e.target;
    setCustomerInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // التعامل مع تغيير طريقة الدفع
  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method);
  };
  
  // التعامل مع تقديم النموذج
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // التحقق من صحة البيانات
    if (!customerInfo.name || !customerInfo.email || !customerInfo.phone) {
      alert('يرجى إدخال جميع البيانات المطلوبة');
      return;
    }
    
    if (!termsAccepted) {
      alert('يرجى الموافقة على الشروط والأحكام');
      return;
    }
    
    // هنا سيتم إرسال الطلب إلى الخادم
    alert('تم إرسال الطلب بنجاح!');
    
    // في التطبيق الحقيقي، سيتم توجيه المستخدم إلى صفحة تأكيد الطلب
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>إتمام الطلب | متجر المنتجات الرقمية</title>
        <meta name="description" content="إتمام عملية الشراء في متجر المنتجات الرقمية" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      {/* الهيدر (يمكن استخراجه كمكون منفصل) */}
      <header className="bg-primary-dark text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-cairo font-bold">متجر رقمي</h1>
          </div>
          <nav className="hidden md:flex space-x-reverse space-x-6">
            <a href="#" className="font-cairo hover:text-accent">الرئيسية</a>
            <a href="#" className="font-cairo hover:text-accent">المنتجات</a>
            <a href="#" className="font-cairo hover:text-accent">العروض</a>
            <a href="#" className="font-cairo hover:text-accent">اتصل بنا</a>
          </nav>
          <div className="flex items-center space-x-reverse space-x-4">
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </a>
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </a>
          </div>
        </div>
      </header>

      {/* مسار التنقل */}
      <div className="bg-white py-2 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm font-tajawal text-neutral">
            <a href="#" className="hover:text-primary">الرئيسية</a>
            <span className="mx-2">/</span>
            <a href="#" className="hover:text-primary">سلة التسوق</a>
            <span className="mx-2">/</span>
            <span className="text-neutral-dark">إتمام الطلب</span>
          </div>
        </div>
      </div>

      {/* عنوان الصفحة */}
      <section className="py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-cairo font-bold text-neutral-dark">إتمام الطلب</h1>
        </div>
      </section>

      {/* محتوى الصفحة */}
      <section className="py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* نموذج الدفع */}
            <div className="lg:w-2/3">
              <form onSubmit={handleSubmit}>
                {/* بيانات العميل */}
                <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                  <div className="p-4 border-b">
                    <h2 className="text-xl font-cairo font-bold text-neutral-dark">بيانات العميل</h2>
                  </div>
                  <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="name" className="block font-cairo font-bold text-neutral-dark mb-2">الاسم الكامل <span className="text-error">*</span></label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={customerInfo.name}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="email" className="block font-cairo font-bold text-neutral-dark mb-2">البريد الإلكتروني <span className="text-error">*</span></label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={customerInfo.email}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="phone" className="block font-cairo font-bold text-neutral-dark mb-2">رقم الجوال <span className="text-error">*</span></label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={customerInfo.phone}
                          onChange={handleCustomerInfoChange}
                          className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                          required
                        />
                      </div>
                    </div>
                    <div className="mt-4 text-sm font-tajawal text-neutral">
                      <p>سيتم استخدام هذه البيانات للتواصل معك وإرسال تفاصيل الطلب.</p>
                    </div>
                  </div>
                </div>

                {/* طرق الدفع */}
                <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                  <div className="p-4 border-b">
                    <h2 className="text-xl font-cairo font-bold text-neutral-dark">طريقة الدفع</h2>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      {/* بطاقات الائتمان */}
                      <div 
                        className={`border rounded-lg p-4 cursor-pointer ${paymentMethod === 'visa' ? 'border-primary bg-blue-50' : 'border-gray-200 hover:border-primary'}`}
                        onClick={() => handlePaymentMethodChange('visa')}
                      >
                        <div className="flex items-center">
                          <input
                            type="radio"
                            id="visa"
                            name="paymentMethod"
                            checked={paymentMethod === 'visa'}
                            onChange={() => handlePaymentMethodChange('visa')}
                            className="ml-2 h-4 w-4 text-primary focus:ring-primary border-gray-300"
                          />
                          <label htmlFor="visa" className="flex items-center cursor-pointer">
                            <div className="bg-gray-100 rounded p-2 w-12 h-8 flex items-center justify-center ml-3">
                              <span className="text-xs font-cairo">Visa</span>
                            </div>
                            <div className="bg-gray-100 rounded p-2 w-12 h-8 flex items-center justify-center ml-3">
                              <span className="text-xs font-cairo">MC</span>
                            </div>
                            <span className="font-cairo font-bold text-neutral-dark">بطاقة ائتمان</span>
                          </label>
                        </div>
                        {paymentMethod === 'visa' && (
                          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label htmlFor="cardNumber" className="block font-cairo text-sm text-neutral-dark mb-1">رقم البطاقة</label>
                              <input
                                type="text"
                                id="cardNumber"
                                placeholder="XXXX XXXX XXXX XXXX"
                                className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label htmlFor="expiry" className="block font-cairo text-sm text-neutral-dark mb-1">تاريخ الانتهاء</label>
                                <input
                                  type="text"
                                  id="expiry"
                                  placeholder="MM/YY"
                                  className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                                />
                              </div>
                              <div>
                                <label htmlFor="cvv" className="block font-cairo text-sm text-neutral-dark mb-1">CVV</label>
                                <input
                                  type="text"
                                  id="cvv"
                                  placeholder="XXX"
                                  className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* مدى */}
                      <div 
                        className={`border rounded-lg p-4 cursor-pointer ${paymentMethod === 'mada' ? 'border-primary bg-blue-50' : 'border-gray-200 hover:border-primary'}`}
                        onClick={() => handlePaymentMethodChange('mada')}
                      >
                        <div className="flex items-center">
                          <input
                            type="radio"
                            id="mada"
                            name="paymentMethod"
                            checked={paymentMethod === 'mada'}
                            onChange={() => handlePaymentMethodChange('mada')}
                            className="ml-2 h-4 w-4 text-primary focus:ring-primary border-gray-300"
                          />
                          <label htmlFor="mada" className="flex items-center cursor-pointer">
                            <div className="bg-gray-100 rounded p-2 w-12 h-8 flex items-center justify-center ml-3">
                              <span className="text-xs font-cairo">مدى</span>
                            </div>
                            <span className="font-cairo font-bold text-neutral-dark">بطاقة مدى</span>
                          </label>
                        </div>
                        {paymentMethod === 'mada' && (
                          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label htmlFor="madaCardNumber" className="block font-cairo text-sm text-neutral-dark mb-1">رقم البطاقة</label>
                              <input
                                type="text"
                                id="madaCardNumber"
                                placeholder="XXXX XXXX XXXX XXXX"
                                className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label htmlFor="madaExpiry" className="block font-cairo text-sm text-neutral-dark mb-1">تاريخ الانتهاء</label>
                                <input
                                  type="text"
                                  id="madaExpiry"
                                  placeholder="MM/YY"
                                  className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                                />
                              </div>
                              <div>
                                <label htmlFor="madaCvv" className="block font-cairo text-sm text-neutral-dark mb-1">CVV</label>
                                <input
                                  type="text"
                                  id="madaCvv"
                                  placeholder="XXX"
                                  className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* STC Pay */}
                      <div 
                        className={`border rounded-lg p-4 cursor-pointer ${paymentMethod === 'stcpay' ? 'border-primary bg-blue-50' : 'border-gray-200 hover:border-primary'}`}
                        onClick={() => handlePaymentMethodChange('stcpay')}
                      >
                        <div className="flex items-center">
                          <input
                            type="radio"
                            id="stcpay"
                            name="paymentMethod"
                            checked={paymentMethod === 'stcpay'}
                            onChange={() => handlePaymentMethodChange('stcpay')}
                            className="ml-2 h-4 w-4 text-primary focus:ring-primary border-gray-300"
                          />
                          <label htmlFor="stcpay" className="flex items-center cursor-pointer">
                            <div className="bg-gray-100 rounded p-2 w-16 h-8 flex items-center justify-center ml-3">
                              <span className="text-xs font-cairo">STC Pay</span>
                            </div>
                            <span className="font-cairo font-bold text-neutral-dark">STC Pay</span>
                          </label>
                        </div>
                        {paymentMethod === 'stcpay' && (
                          <div className="mt-4">
                            <div>
                              <label htmlFor="stcPayNumber" className="block font-cairo text-sm text-neutral-dark mb-1">رقم الجوال المسجل في STC Pay</label>
                              <input
                                type="tel"
                                id="stcPayNumber"
                                placeholder="05XXXXXXXX"
                                className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Apple Pay */}
                      <div 
                        className={`border rounded-lg p-4 cursor-pointer ${paymentMethod === 'applepay' ? 'border-primary bg-blue-50' : 'border-gray-200 hover:border-primary'}`}
                        onClick={() => handlePaymentMethodChange('applepay')}
                      >
                        <div className="flex items-center">
                          <input
                            type="radio"
                            id="applepay"
                            name="paymentMethod"
                            checked={paymentMethod === 'applepay'}
                            onChange={() => handlePaymentMethodChange('applepay')}
                            className="ml-2 h-4 w-4 text-primary focus:ring-primary border-gray-300"
                          />
                          <label htmlFor="applepay" className="flex items-center cursor-pointer">
                            <div className="bg-gray-100 rounded p-2 w-16 h-8 flex items-center justify-center ml-3">
                              <span className="text-xs font-cairo">Apple Pay</span>
                            </div>
                            <span className="font-cairo font-bold text-neutral-dark">Apple Pay</span>
                          </label>
                        </div>
                        {paymentMethod === 'applepay' && (
                          <div className="mt-4 text-center">
                            <button type="button" className="bg-black text-white font-cairo font-bold py-3 px-6 rounded-lg transition duration-300 flex items-center justify-center mx-auto">
                              <svg className="h-5 w-5 ml-2" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M17.6 7.8c-.7.8-1.7 1.3-2.7 1.3-1.3 0-1.8-.6-2.9-.6-1.1 0-1.9.6-2.9.6-1.1 0-2.1-.6-2.8-1.5-1.9-2.6-.5-6.5 1.4-8.2.9-.8 2-.9 2.7-.9 1.1 0 1.7.6 2.8.6 1 0 1.6-.6 2.8-.6.7 0 1.8.2 2.7.9-.1 0-1.6.9-1.6 2.8 0 2.2 1.9 2.9 1.9 2.9-.1.4-.3.9-.5 1.3-.5.9-1 1.8-1.9 2.4zm-2.2-9.7c-.8.9-1.9 1.6-2.9 1.6-.1-.8 0-1.7.5-2.5.5-.8 1.5-1.5 2.6-1.6.1.9 0 1.7-.2 2.5z" />
                              </svg>
                              الدفع باستخدام Apple Pay
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* الشروط والأحكام */}
                <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
                  <div className="p-6">
                    <div className="flex items-start">
                      <input
                        type="checkbox"
                        id="terms"
                        checked={termsAccepted}
                        onChange={() => setTermsAccepted(!termsAccepted)}
                        className="mt-1 ml-2 h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                      />
                      <label htmlFor="terms" className="font-tajawal text-neutral">
                        أوافق على <a href="#" className="text-primary hover:underline">الشروط والأحكام</a> و<a href="#" className="text-primary hover:underline">سياسة الخصوصية</a>
                      </label>
                    </div>
                  </div>
                </div>

                {/* زر إتمام الطلب */}
                <div className="flex justify-between items-center">
                  <a href="#" className="inline-flex items-center font-cairo text-primary hover:text-primary-dark transition duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    العودة إلى سلة التسوق
                  </a>
                  <button
                    type="submit"
                    className="bg-accent hover:bg-yellow-500 text-primary-dark font-cairo font-bold py-3 px-6 rounded-lg transition duration-300 flex items-center justify-center"
                  >
                    إتمام الطلب
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </button>
                </div>
              </form>
            </div>
            
            {/* ملخص الطلب */}
            <div className="lg:w-1/3">
              <div className="bg-white rounded-lg shadow-md overflow-hidden sticky top-6">
                <div className="p-4 border-b">
                  <h2 className="text-xl font-cairo font-bold text-neutral-dark">ملخص الطلب</h2>
                </div>
                
                <div className="p-4">
                  {/* قائمة المنتجات */}
                  <div className="space-y-4 mb-6">
                    {orderItems.map((item) => (
                      <div key={item.id} className="flex justify-between items-center pb-3 border-b border-gray-100">
                        <div>
                          <h3 className="font-cairo font-bold text-neutral-dark">{item.name}</h3>
                          <p className="text-sm font-tajawal text-neutral">الكمية: {item.quantity}</p>
                        </div>
                        <span className="font-cairo font-bold text-primary-dark">{(item.price * item.quantity).toFixed(2)} ريال</span>
                      </div>
                    ))}
                  </div>
                  
                  {/* تفاصيل الدفع */}
                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between">
                      <span className="font-tajawal text-neutral">المجموع الفرعي:</span>
                      <span className="font-cairo font-bold text-neutral-dark">{getSubtotal().toFixed(2)} ريال</span>
                    </div>
                    <div className="border-t pt-3 flex justify-between">
                      <span className="font-cairo font-bold text-neutral-dark">المجموع:</span>
                      <span className="font-cairo font-bold text-primary-dark text-xl">{getSubtotal().toFixed(2)} ريال</span>
                    </div>
                  </div>
                  
                  {/* معلومات الأمان */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-success ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                      <span className="font-cairo font-bold text-neutral-dark">دفع آمن 100%</span>
                    </div>
                    <p className="text-sm font-tajawal text-neutral">جميع المعاملات مشفرة ومؤمنة بالكامل.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* الفوتر (يمكن استخراجه كمكون منفصل) */}
      <footer className="bg-primary-dark text-white py-10 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">متجر رقمي</h3>
              <p className="font-tajawal mb-4">متجرك الأول للمنتجات الرقمية بأفضل الأسعار وتسليم فوري</p>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">روابط سريعة</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الرئيسية</a></li>
                <li><a href="#" className="hover:text-accent">المنتجات</a></li>
                <li><a href="#" className="hover:text-accent">العروض</a></li>
                <li><a href="#" className="hover:text-accent">من نحن</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">خدمة العملاء</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-accent">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent">شروط الاستخدام</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">اتصل بنا</h3>
              <ul className="font-tajawal space-y-2">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>info@digitalstore.com</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span>+966 55 1234567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center">
            <p className="font-tajawal">جميع الحقوق محفوظة © {new Date().getFullYear()} متجر رقمي</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
