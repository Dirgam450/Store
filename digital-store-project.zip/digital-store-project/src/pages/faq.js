import React, { useState } from 'react';
import Head from 'next/head';

export default function FAQPage() {
  // حالة توسيع/طي الأسئلة
  const [expandedQuestions, setExpandedQuestions] = useState({});
  
  // قائمة الأسئلة الشائعة مقسمة حسب الفئات
  const faqCategories = [
    {
      id: 'general',
      title: 'أسئلة عامة',
      questions: [
        {
          id: 'q1',
          question: 'ما هو متجر رقمي؟',
          answer: 'متجر رقمي هو منصة إلكترونية متخصصة في بيع المنتجات الرقمية مثل شدات ببجي، بطاقات Google Play، بطاقات iTunes، رصيد Free Fire، وغيرها من المنتجات الرقمية. نوفر خدمة التسليم الفوري للأكواد الرقمية بعد إتمام عملية الدفع مباشرة.'
        },
        {
          id: 'q2',
          question: 'هل المتجر آمن للشراء؟',
          answer: 'نعم، متجر رقمي يستخدم أحدث تقنيات الأمان لحماية بياناتك الشخصية ومعلومات الدفع. نحن نستخدم بروتوكول SSL لتشفير جميع البيانات المتبادلة، كما أن جميع عمليات الدفع تتم عبر بوابات دفع موثوقة ومعتمدة.'
        },
        {
          id: 'q3',
          question: 'هل يمكنني الشراء بدون تسجيل حساب؟',
          answer: 'نعم، يمكنك الشراء كزائر بدون الحاجة لإنشاء حساب. ومع ذلك، ننصح بإنشاء حساب للاستفادة من ميزات إضافية مثل تتبع الطلبات، الوصول إلى الأكواد المشتراة سابقاً، والحصول على عروض خاصة.'
        }
      ]
    },
    {
      id: 'payment',
      title: 'الدفع والأسعار',
      questions: [
        {
          id: 'q4',
          question: 'ما هي طرق الدفع المتاحة؟',
          answer: 'نوفر العديد من طرق الدفع المختلفة لتناسب جميع العملاء، وتشمل: بطاقات مدى، بطاقات الائتمان (Visa/Mastercard)، STC Pay، Apple Pay، وPayPal. جميع طرق الدفع آمنة ومشفرة لضمان حماية بياناتك.'
        },
        {
          id: 'q5',
          question: 'هل هناك رسوم إضافية على عملية الشراء؟',
          answer: 'لا، السعر المعروض هو السعر النهائي الذي ستدفعه. لا توجد أي رسوم إضافية أو خفية على عمليات الشراء من متجرنا.'
        },
        {
          id: 'q6',
          question: 'كيف يمكنني استخدام كوبون الخصم؟',
          answer: 'يمكنك استخدام كوبون الخصم عند إتمام عملية الشراء في صفحة سلة التسوق. ما عليك سوى إدخال رمز الكوبون في الحقل المخصص والضغط على زر "تطبيق" ليتم خصم قيمة الكوبون من إجمالي الطلب.'
        }
      ]
    },
    {
      id: 'products',
      title: 'المنتجات والأكواد',
      questions: [
        {
          id: 'q7',
          question: 'كيف أحصل على الكود بعد الشراء؟',
          answer: 'بعد إتمام عملية الدفع بنجاح، سيتم عرض الكود مباشرة على صفحة تأكيد الطلب. كما سيتم إرسال الكود إلى بريدك الإلكتروني ورقم الجوال المسجل. يمكنك أيضاً الوصول إلى جميع الأكواد المشتراة من خلال حسابك في قسم "الأكواد المشتراة".'
        },
        {
          id: 'q8',
          question: 'ما هي مدة صلاحية الأكواد؟',
          answer: 'تختلف مدة صلاحية الأكواد حسب نوع المنتج. عادةً ما تكون أكواد شدات ببجي وFree Fire صالحة لمدة 30 يوماً، بينما تكون بطاقات Google Play وiTunes صالحة لمدة سنة كاملة. يمكنك معرفة مدة صلاحية كل كود من صفحة تفاصيل المنتج أو من حسابك بعد الشراء.'
        },
        {
          id: 'q9',
          question: 'ماذا أفعل إذا لم يعمل الكود؟',
          answer: 'في حالة واجهتك مشكلة مع الكود، يرجى التأكد أولاً من إدخاله بشكل صحيح. إذا استمرت المشكلة، يرجى التواصل معنا فوراً عبر خدمة العملاء أو واتساب، وسنقوم بحل المشكلة في أسرع وقت ممكن. نحن نضمن جميع الأكواد التي نبيعها.'
        }
      ]
    },
    {
      id: 'account',
      title: 'الحساب والخصوصية',
      questions: [
        {
          id: 'q10',
          question: 'كيف يمكنني إنشاء حساب؟',
          answer: 'يمكنك إنشاء حساب بسهولة من خلال الضغط على أيقونة "الحساب" في أعلى الصفحة، ثم اختيار "إنشاء حساب جديد". قم بإدخال اسمك، بريدك الإلكتروني، رقم الجوال، وكلمة المرور، ثم اضغط على زر "إنشاء حساب".'
        },
        {
          id: 'q11',
          question: 'كيف يمكنني استعادة كلمة المرور؟',
          answer: 'إذا نسيت كلمة المرور، يمكنك استعادتها بسهولة من خلال الضغط على رابط "نسيت كلمة المرور؟" في صفحة تسجيل الدخول. سيتم إرسال رابط لإعادة تعيين كلمة المرور إلى بريدك الإلكتروني المسجل.'
        },
        {
          id: 'q12',
          question: 'هل بياناتي الشخصية آمنة؟',
          answer: 'نعم، نحن نأخذ خصوصية وأمان بياناتك على محمل الجد. نحن لا نشارك بياناتك الشخصية مع أي طرف ثالث دون موافقتك، ونستخدم أحدث تقنيات التشفير لحماية جميع البيانات. يمكنك الاطلاع على سياسة الخصوصية الخاصة بنا لمزيد من المعلومات.'
        }
      ]
    },
    {
      id: 'support',
      title: 'الدعم والمساعدة',
      questions: [
        {
          id: 'q13',
          question: 'كيف يمكنني التواصل مع خدمة العملاء؟',
          answer: 'يمكنك التواصل مع فريق خدمة العملاء من خلال عدة طرق: الواتساب على الرقم +966 55 1234567، البريد الإلكتروني info@digitalstore.com، أو من خلال نموذج الاتصال في صفحة "اتصل بنا". فريق الدعم متاح على مدار الساعة طوال أيام الأسبوع.'
        },
        {
          id: 'q14',
          question: 'ما هي ساعات عمل خدمة العملاء؟',
          answer: 'فريق خدمة العملاء متاح على مدار الساعة (24/7) للرد على استفساراتك ومساعدتك في حل أي مشكلة قد تواجهها.'
        },
        {
          id: 'q15',
          question: 'هل يمكنني استرجاع المنتج الرقمي بعد الشراء؟',
          answer: 'نظراً لطبيعة المنتجات الرقمية، لا يمكن استرجاعها بعد استلام الكود. ومع ذلك، إذا واجهتك أي مشكلة مع الكود أو لم تتمكن من استخدامه، يرجى التواصل مع خدمة العملاء وسنقوم بمساعدتك وإيجاد الحل المناسب.'
        }
      ]
    }
  ];
  
  // التعامل مع توسيع/طي السؤال
  const toggleQuestion = (questionId) => {
    setExpandedQuestions(prev => ({
      ...prev,
      [questionId]: !prev[questionId]
    }));
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>الأسئلة الشائعة | متجر المنتجات الرقمية</title>
        <meta name="description" content="الأسئلة الشائعة حول متجر المنتجات الرقمية، طرق الدفع، الأكواد، وخدمة العملاء" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      {/* الهيدر (يمكن استخراجه كمكون منفصل) */}
      <header className="bg-primary-dark text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-cairo font-bold">متجر رقمي</h1>
          </div>
          <nav className="hidden md:flex space-x-reverse space-x-6">
            <a href="#" className="font-cairo hover:text-accent">الرئيسية</a>
            <a href="#" className="font-cairo hover:text-accent">المنتجات</a>
            <a href="#" className="font-cairo hover:text-accent">العروض</a>
            <a href="#" className="font-cairo hover:text-accent">اتصل بنا</a>
          </nav>
          <div className="flex items-center space-x-reverse space-x-4">
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </a>
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </a>
          </div>
        </div>
      </header>

      {/* مسار التنقل */}
      <div className="bg-white py-2 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm font-tajawal text-neutral">
            <a href="#" className="hover:text-primary">الرئيسية</a>
            <span className="mx-2">/</span>
            <span className="text-neutral-dark">الأسئلة الشائعة</span>
          </div>
        </div>
      </div>

      {/* عنوان الصفحة */}
      <section className="py-8 bg-gradient-to-l from-primary-dark to-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-cairo font-bold mb-2">الأسئلة الشائعة</h1>
          <p className="font-tajawal text-lg">إجابات على الأسئلة الأكثر شيوعاً حول متجرنا ومنتجاتنا</p>
        </div>
      </section>

      {/* محتوى الصفحة */}
      <section className="py-10">
        <div className="container mx-auto px-4">
          {/* مربع البحث */}
          <div className="max-w-2xl mx-auto mb-10">
            <div className="relative">
              <input
                type="text"
                placeholder="ابحث في الأسئلة الشائعة..."
                className="w-full border border-gray-300 rounded-lg py-3 px-4 pr-12 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>
          
          {/* الفئات والأسئلة */}
          <div className="max-w-3xl mx-auto">
            {faqCategories.map((category) => (
              <div key={category.id} className="mb-8">
                <h2 className="text-2xl font-cairo font-bold text-neutral-dark mb-4">{category.title}</h2>
                
                <div className="space-y-4">
                  {category.questions.map((item) => (
                    <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                      <button
                        className="w-full flex items-center justify-between p-4 text-right"
                        onClick={() => toggleQuestion(item.id)}
                      >
                        <h3 className="font-cairo font-bold text-lg text-neutral-dark">{item.question}</h3>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className={`h-5 w-5 text-primary transition-transform duration-200 ${expandedQuestions[item.id] ? 'transform rotate-180' : ''}`}
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                      
                      {expandedQuestions[item.id] && (
                        <div className="p-4 pt-0 border-t">
                          <p className="font-tajawal text-neutral">{item.answer}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          {/* لم تجد إجابة؟ */}
          <div className="max-w-3xl mx-auto mt-12 bg-blue-50 rounded-lg p-6 border border-blue-100">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/4 mb-4 md:mb-0 text-center">
                <div className="bg-primary-light text-primary-dark rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </div>
              </div>
              <div className="md:w-3/4 md:pr-6">
                <h3 className="font-cairo font-bold text-xl text-neutral-dark mb-2">لم تجد إجابة لسؤالك؟</h3>
                <p className="font-tajawal text-neutral mb-4">فريق خدمة العملاء متاح على مدار الساعة للإجابة على جميع استفساراتك</p>
                <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-reverse sm:space-x-3">
                  <a href="#" className="bg-accent hover:bg-yellow-500 text-primary-dark font-cairo font-bold py-2 px-4 rounded-lg inline-flex items-center justify-center transition duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                    تواصل عبر واتساب
                  </a>
                  <a href="#" className="bg-primary hover:bg-primary-dark text-white font-cairo font-bold py-2 px-4 rounded-lg inline-flex items-center justify-center transition duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                    </svg>
                    راسلنا
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* الفوتر (يمكن استخراجه كمكون منفصل) */}
      <footer className="bg-primary-dark text-white py-10 mt-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">متجر رقمي</h3>
              <p className="font-tajawal mb-4">متجرك الأول للمنتجات الرقمية بأفضل الأسعار وتسليم فوري</p>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">روابط سريعة</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الرئيسية</a></li>
                <li><a href="#" className="hover:text-accent">المنتجات</a></li>
                <li><a href="#" className="hover:text-accent">العروض</a></li>
                <li><a href="#" className="hover:text-accent">من نحن</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">خدمة العملاء</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-accent">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent">شروط الاستخدام</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">اتصل بنا</h3>
              <ul className="font-tajawal space-y-2">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>info@digitalstore.com</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span>+966 55 1234567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center">
            <p className="font-tajawal">جميع الحقوق محفوظة © {new Date().getFullYear()} متجر رقمي</p>
          </div>
        </div>
      </footer>
      
      {/* زر واتساب الثابت */}
      <div className="fixed bottom-6 left-6 z-50">
        <a
          href="https://wa.me/966551234567"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-500 hover:bg-green-600 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg transition duration-300"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="currentColor" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
          </svg>
        </a>
      </div>
    </div>
  );
}
