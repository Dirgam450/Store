import React, { useState } from 'react';
import Head from 'next/head';

export default function UserDashboard() {
  // حالة التبويب النشط
  const [activeTab, setActiveTab] = useState('orders');
  
  // بيانات المستخدم (ستأتي من Firebase لاحقاً)
  const user = {
    name: 'محمد أحمد',
    email: 'mohammed@example.com',
    phone: '966501234567',
    joinDate: '15/03/2025'
  };
  
  // بيانات الطلبات (ستأتي من Firebase لاحقاً)
  const orders = [
    {
      id: 'ORD-12345',
      date: '2025-06-01',
      total: 229.98,
      status: 'completed',
      items: [
        { name: 'شدات ببجي - 660 UC', price: 39.99, quantity: 1 },
        { name: 'بطاقة Google Play - 50$', price: 189.99, quantity: 1 }
      ]
    },
    {
      id: 'ORD-12344',
      date: '2025-05-25',
      total: 129.99,
      status: 'completed',
      items: [
        { name: 'رويال باس ببجي', price: 129.99, quantity: 1 }
      ]
    },
    {
      id: 'ORD-12343',
      date: '2025-05-10',
      total: 39.99,
      status: 'completed',
      items: [
        { name: 'بطاقة iTunes - 10$', price: 39.99, quantity: 1 }
      ]
    }
  ];
  
  // بيانات الأكواد المشتراة (ستأتي من Firebase لاحقاً)
  const codes = [
    {
      id: 'CODE-12345',
      product: 'شدات ببجي - 660 UC',
      code: 'PUBG-XXXX-XXXX-XXXX',
      purchaseDate: '2025-06-01',
      expiryDate: '2025-07-01',
      status: 'unused'
    },
    {
      id: 'CODE-12344',
      product: 'بطاقة Google Play - 50$',
      code: 'GPLAY-XXXX-XXXX-XXXX',
      purchaseDate: '2025-06-01',
      expiryDate: '2026-06-01',
      status: 'unused'
    },
    {
      id: 'CODE-12343',
      product: 'رويال باس ببجي',
      code: 'PUBG-XXXX-XXXX-XXXX',
      purchaseDate: '2025-05-25',
      expiryDate: '2025-06-25',
      status: 'used'
    },
    {
      id: 'CODE-12342',
      product: 'بطاقة iTunes - 10$',
      code: 'ITUNES-XXXX-XXXX-XXXX',
      purchaseDate: '2025-05-10',
      expiryDate: '2026-05-10',
      status: 'used'
    }
  ];
  
  // ترجمة حالة الطلب
  const getStatusText = (status) => {
    switch (status) {
      case 'pending':
        return 'قيد الانتظار';
      case 'processing':
        return 'قيد المعالجة';
      case 'completed':
        return 'مكتمل';
      case 'cancelled':
        return 'ملغي';
      default:
        return status;
    }
  };
  
  // ترجمة حالة الكود
  const getCodeStatusText = (status) => {
    switch (status) {
      case 'unused':
        return 'غير مستخدم';
      case 'used':
        return 'مستخدم';
      case 'expired':
        return 'منتهي الصلاحية';
      default:
        return status;
    }
  };
  
  // تنسيق التاريخ
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA');
  };
  
  // تحديث بيانات المستخدم
  const handleUpdateProfile = (e) => {
    e.preventDefault();
    alert('تم تحديث البيانات بنجاح');
  };
  
  // تغيير كلمة المرور
  const handleChangePassword = (e) => {
    e.preventDefault();
    alert('تم تغيير كلمة المرور بنجاح');
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      <Head>
        <title>لوحة تحكم المستخدم | متجر المنتجات الرقمية</title>
        <meta name="description" content="لوحة تحكم المستخدم في متجر المنتجات الرقمية" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      {/* الهيدر (يمكن استخراجه كمكون منفصل) */}
      <header className="bg-primary-dark text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-cairo font-bold">متجر رقمي</h1>
          </div>
          <nav className="hidden md:flex space-x-reverse space-x-6">
            <a href="#" className="font-cairo hover:text-accent">الرئيسية</a>
            <a href="#" className="font-cairo hover:text-accent">المنتجات</a>
            <a href="#" className="font-cairo hover:text-accent">العروض</a>
            <a href="#" className="font-cairo hover:text-accent">اتصل بنا</a>
          </nav>
          <div className="flex items-center space-x-reverse space-x-4">
            <a href="#" className="hover:text-accent">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </a>
            <div className="relative group">
              <button className="flex items-center hover:text-accent">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                <span className="mr-1 font-cairo">{user.name}</span>
              </button>
              <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 hidden group-hover:block">
                <a href="#" className="block px-4 py-2 text-sm text-neutral-dark font-cairo hover:bg-gray-100">لوحة التحكم</a>
                <a href="#" className="block px-4 py-2 text-sm text-neutral-dark font-cairo hover:bg-gray-100">طلباتي</a>
                <a href="#" className="block px-4 py-2 text-sm text-neutral-dark font-cairo hover:bg-gray-100">الإعدادات</a>
                <div className="border-t border-gray-100"></div>
                <a href="#" className="block px-4 py-2 text-sm text-error font-cairo hover:bg-gray-100">تسجيل الخروج</a>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* مسار التنقل */}
      <div className="bg-white py-2 shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center text-sm font-tajawal text-neutral">
            <a href="#" className="hover:text-primary">الرئيسية</a>
            <span className="mx-2">/</span>
            <span className="text-neutral-dark">لوحة تحكم المستخدم</span>
          </div>
        </div>
      </div>

      {/* محتوى الصفحة */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-cairo font-bold text-neutral-dark mb-6">لوحة تحكم المستخدم</h1>
          
          <div className="flex flex-col lg:flex-row gap-6">
            {/* القائمة الجانبية */}
            <div className="lg:w-1/4">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-6 bg-primary-dark text-white text-center">
                  <div className="w-20 h-20 rounded-full bg-white text-primary-dark flex items-center justify-center text-2xl font-bold mx-auto mb-3">
                    {user.name.charAt(0)}
                  </div>
                  <h2 className="font-cairo font-bold text-xl">{user.name}</h2>
                  <p className="font-tajawal text-sm opacity-75">عضو منذ {user.joinDate}</p>
                </div>
                
                <nav className="p-4">
                  <ul className="space-y-1">
                    <li>
                      <button
                        onClick={() => setActiveTab('orders')}
                        className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${
                          activeTab === 'orders' ? 'bg-primary-light text-primary-dark' : 'hover:bg-gray-100'
                        }`}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                        </svg>
                        طلباتي
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => setActiveTab('codes')}
                        className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${
                          activeTab === 'codes' ? 'bg-primary-light text-primary-dark' : 'hover:bg-gray-100'
                        }`}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
                        </svg>
                        الأكواد المشتراة
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => setActiveTab('profile')}
                        className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${
                          activeTab === 'profile' ? 'bg-primary-light text-primary-dark' : 'hover:bg-gray-100'
                        }`}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        المعلومات الشخصية
                      </button>
                    </li>
                    <li>
                      <button
                        onClick={() => setActiveTab('password')}
                        className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${
                          activeTab === 'password' ? 'bg-primary-light text-primary-dark' : 'hover:bg-gray-100'
                        }`}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                        تغيير كلمة المرور
                      </button>
                    </li>
                  </ul>
                  
                  <div className="border-t my-4"></div>
                  
                  <button className="w-full flex items-center py-2 px-3 rounded-lg font-cairo text-error hover:bg-red-50 transition duration-200">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                    </svg>
                    تسجيل الخروج
                  </button>
                </nav>
              </div>
            </div>
            
            {/* المحتوى الرئيسي */}
            <div className="lg:w-3/4">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                {/* طلباتي */}
                {activeTab === 'orders' && (
                  <div>
                    <div className="p-4 border-b">
                      <h2 className="text-xl font-cairo font-bold text-neutral-dark">طلباتي</h2>
                    </div>
                    
                    <div className="p-4">
                      {orders.length > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="w-full">
                            <thead>
                              <tr className="bg-gray-50">
                                <th className="py-3 px-4 text-right font-cairo text-neutral-dark">رقم الطلب</th>
                                <th className="py-3 px-4 text-right font-cairo text-neutral-dark">التاريخ</th>
                                <th className="py-3 px-4 text-right font-cairo text-neutral-dark">المجموع</th>
                                <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الحالة</th>
                                <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الإجراءات</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y">
                              {orders.map((order) => (
                                <tr key={order.id} className="hover:bg-gray-50">
                                  <td className="py-3 px-4 font-cairo">{order.id}</td>
                                  <td className="py-3 px-4 font-tajawal">{formatDate(order.date)}</td>
                                  <td className="py-3 px-4 font-cairo">{order.total.toFixed(2)} ريال</td>
                                  <td className="py-3 px-4">
                                    <span className={`inline-block py-1 px-2 rounded-full text-xs font-cairo ${
                                      order.status === 'completed' ? 'bg-green-100 text-green-800' :
                                      order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                                      order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                      'bg-red-100 text-red-800'
                                    }`}>
                                      {getStatusText(order.status)}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4">
                                    <button className="text-primary hover:text-primary-dark font-cairo text-sm">
                                      عرض التفاصيل
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-neutral" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                          </svg>
                          <h3 className="font-cairo font-bold text-lg mt-4 mb-2">لا توجد طلبات</h3>
                          <p className="font-tajawal text-neutral">لم تقم بإجراء أي طلبات بعد.</p>
                          <a href="#" className="inline-block mt-4 bg-primary hover:bg-primary-dark text-white font-cairo py-2 px-4 rounded-lg transition duration-300">
                            تصفح المنتجات
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                {/* الأكواد المشتراة */}
                {activeTab === 'codes' && (
                  <div>
                    <div className="p-4 border-b">
                      <h2 className="text-xl font-cairo font-bold text-neutral-dark">الأكواد المشتراة</h2>
                    </div>
                    
                    <div className="p-4">
                      {codes.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {codes.map((code) => (
                            <div key={code.id} className="border rounded-lg overflow-hidden">
                              <div className="p-4 bg-gray-50 border-b">
                                <h3 className="font-cairo font-bold">{code.product}</h3>
                              </div>
                              <div className="p-4">
                                <div className="space-y-2">
                                  <div className="flex justify-between">
                                    <span className="font-tajawal text-neutral">الكود:</span>
                                    <span className="font-cairo font-bold">{code.code}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-tajawal text-neutral">تاريخ الشراء:</span>
                                    <span className="font-tajawal">{formatDate(code.purchaseDate)}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-tajawal text-neutral">تاريخ الانتهاء:</span>
                                    <span className="font-tajawal">{formatDate(code.expiryDate)}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span className="font-tajawal text-neutral">الحالة:</span>
                                    <span className={`font-cairo ${
                                      code.status === 'unused' ? 'text-success' :
                                      code.status === 'used' ? 'text-neutral' :
                                      'text-error'
                                    }`}>
                                      {getCodeStatusText(code.status)}
                                    </span>
                                  </div>
                                </div>
                                
                                <div className="mt-4 flex justify-end">
                                  <button className="bg-primary hover:bg-primary-dark text-white font-cairo py-1 px-3 rounded-lg text-sm transition duration-300">
                                    نسخ الكود
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-neutral" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
                          </svg>
                          <h3 className="font-cairo font-bold text-lg mt-4 mb-2">لا توجد أكواد</h3>
                          <p className="font-tajawal text-neutral">لم تقم بشراء أي أكواد بعد.</p>
                          <a href="#" className="inline-block mt-4 bg-primary hover:bg-primary-dark text-white font-cairo py-2 px-4 rounded-lg transition duration-300">
                            تصفح المنتجات
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                
                {/* المعلومات الشخصية */}
                {activeTab === 'profile' && (
                  <div>
                    <div className="p-4 border-b">
                      <h2 className="text-xl font-cairo font-bold text-neutral-dark">المعلومات الشخصية</h2>
                    </div>
                    
                    <div className="p-6">
                      <form onSubmit={handleUpdateProfile}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <label htmlFor="name" className="block font-cairo font-bold text-neutral-dark mb-2">الاسم الكامل</label>
                            <input
                              type="text"
                              id="name"
                              defaultValue={user.name}
                              className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label htmlFor="email" className="block font-cairo font-bold text-neutral-dark mb-2">البريد الإلكتروني</label>
                            <input
                              type="email"
                              id="email"
                              defaultValue={user.email}
                              className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label htmlFor="phone" className="block font-cairo font-bold text-neutral-dark mb-2">رقم الجوال</label>
                            <input
                              type="tel"
                              id="phone"
                              defaultValue={user.phone}
                              className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </div>
                        </div>
                        
                        <div className="mt-6 flex justify-end">
                          <button
                            type="submit"
                            className="bg-primary hover:bg-primary-dark text-white font-cairo font-bold py-2 px-6 rounded-lg transition duration-300"
                          >
                            حفظ التغييرات
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}
                
                {/* تغيير كلمة المرور */}
                {activeTab === 'password' && (
                  <div>
                    <div className="p-4 border-b">
                      <h2 className="text-xl font-cairo font-bold text-neutral-dark">تغيير كلمة المرور</h2>
                    </div>
                    
                    <div className="p-6">
                      <form onSubmit={handleChangePassword}>
                        <div className="space-y-4">
                          <div>
                            <label htmlFor="currentPassword" className="block font-cairo font-bold text-neutral-dark mb-2">كلمة المرور الحالية</label>
                            <input
                              type="password"
                              id="currentPassword"
                              className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label htmlFor="newPassword" className="block font-cairo font-bold text-neutral-dark mb-2">كلمة المرور الجديدة</label>
                            <input
                              type="password"
                              id="newPassword"
                              className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </div>
                          <div>
                            <label htmlFor="confirmPassword" className="block font-cairo font-bold text-neutral-dark mb-2">تأكيد كلمة المرور الجديدة</label>
                            <input
                              type="password"
                              id="confirmPassword"
                              className="w-full border border-gray-300 rounded-lg py-2 px-3 font-tajawal focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            />
                          </div>
                        </div>
                        
                        <div className="mt-6 flex justify-end">
                          <button
                            type="submit"
                            className="bg-primary hover:bg-primary-dark text-white font-cairo font-bold py-2 px-6 rounded-lg transition duration-300"
                          >
                            تغيير كلمة المرور
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* الفوتر (يمكن استخراجه كمكون منفصل) */}
      <footer className="bg-primary-dark text-white py-10 mt-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">متجر رقمي</h3>
              <p className="font-tajawal mb-4">متجرك الأول للمنتجات الرقمية بأفضل الأسعار وتسليم فوري</p>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">روابط سريعة</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الرئيسية</a></li>
                <li><a href="#" className="hover:text-accent">المنتجات</a></li>
                <li><a href="#" className="hover:text-accent">العروض</a></li>
                <li><a href="#" className="hover:text-accent">من نحن</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">خدمة العملاء</h3>
              <ul className="font-tajawal space-y-2">
                <li><a href="#" className="hover:text-accent">الأسئلة الشائعة</a></li>
                <li><a href="#" className="hover:text-accent">سياسة الخصوصية</a></li>
                <li><a href="#" className="hover:text-accent">شروط الاستخدام</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg mb-4">اتصل بنا</h3>
              <ul className="font-tajawal space-y-2">
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>info@digitalstore.com</span>
                </li>
                <li className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span>+966 55 1234567</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center">
            <p className="font-tajawal">جميع الحقوق محفوظة © {new Date().getFullYear()} متجر رقمي</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
