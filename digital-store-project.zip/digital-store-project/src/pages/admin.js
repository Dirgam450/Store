import React, { useState } from 'react';
import Head from 'next/head';

export default function AdminDashboard() {
  // حالة التبويب النشط
  const [activeTab, setActiveTab] = useState('dashboard');

  // بيانات لوحة التحكم (ستأتي من Firebase لاحقاً)
  const stats = {
    totalSales: 15678.50,
    totalOrders: 345,
    totalUsers: 123,
    totalProducts: 56
  };

  const recentOrders = [
    { id: 'ORD-12345', date: '2025-06-01', total: 229.98, status: 'completed', customer: 'محمد أحمد' },
    { id: 'ORD-12346', date: '2025-06-02', total: 39.99, status: 'processing', customer: 'فاطمة علي' },
    { id: 'ORD-12347', date: '2025-06-03', total: 189.99, status: 'pending', customer: 'خالد عبدالله' },
  ];

  const products = [
    { id: 'prod-001', name: 'شدات ببجي - 660 UC', price: 39.99, stock: 500, category: 'شدات ببجي' },
    { id: 'prod-002', name: 'بطاقة Google Play - 50$', price: 189.99, stock: 250, category: 'بطاقات جوجل بلاي' },
    { id: 'prod-003', name: 'بطاقة iTunes - 10$', price: 39.99, stock: 300, category: 'بطاقات آيتونز' },
  ];

  const users = [
    { id: 'user-001', name: 'محمد أحمد', email: 'mohammed@example.com', joinDate: '15/03/2025' },
    { id: 'user-002', name: 'فاطمة علي', email: 'fatima@example.com', joinDate: '20/04/2025' },
    { id: 'user-003', name: 'خالد عبدالله', email: 'khaled@example.com', joinDate: '01/05/2025' },
  ];

  const codes = [
    { id: 'code-001', product: 'شدات ببجي - 660 UC', code: 'PUBG-AAAA-BBBB-CCCC', status: 'available' },
    { id: 'code-002', product: 'شدات ببجي - 660 UC', code: 'PUBG-DDDD-EEEE-FFFF', status: 'available' },
    { id: 'code-003', product: 'بطاقة Google Play - 50$', code: 'GPLAY-GGGG-HHHH-IIII', status: 'sold' },
  ];

  // ترجمة حالة الطلب
  const getStatusText = (status) => {
    switch (status) {
      case 'pending': return 'قيد الانتظار';
      case 'processing': return 'قيد المعالجة';
      case 'completed': return 'مكتمل';
      case 'cancelled': return 'ملغي';
      default: return status;
    }
  };

  // ترجمة حالة الكود
  const getCodeStatusText = (status) => {
    switch (status) {
      case 'available': return 'متاح';
      case 'sold': return 'مباع';
      case 'used': return 'مستخدم';
      default: return status;
    }
  };

  // تنسيق التاريخ
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA');
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gray-100">
      <Head>
        <title>لوحة تحكم المشرف | متجر المنتجات الرقمية</title>
        <meta name="description" content="لوحة تحكم المشرف لإدارة متجر المنتجات الرقمية" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet" />
      </Head>

      <div className="flex">
        {/* القائمة الجانبية للوحة التحكم */}
        <aside className="w-64 bg-primary-dark text-white min-h-screen p-4">
          <div className="mb-8 text-center">
            <h1 className="text-2xl font-cairo font-bold">لوحة التحكم</h1>
            <span className="text-sm font-tajawal opacity-75">متجر رقمي</span>
          </div>
          <nav>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${activeTab === 'dashboard' ? 'bg-primary text-white' : 'hover:bg-primary-light hover:text-primary-dark'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>
                  نظرة عامة
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('products')}
                  className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${activeTab === 'products' ? 'bg-primary text-white' : 'hover:bg-primary-light hover:text-primary-dark'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
                  إدارة المنتجات
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${activeTab === 'orders' ? 'bg-primary text-white' : 'hover:bg-primary-light hover:text-primary-dark'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" /></svg>
                  إدارة الطلبات
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('users')}
                  className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${activeTab === 'users' ? 'bg-primary text-white' : 'hover:bg-primary-light hover:text-primary-dark'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-1a6 6 0 00-1.757-4.126M15 21H9" /></svg>
                  إدارة المستخدمين
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('codes')}
                  className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${activeTab === 'codes' ? 'bg-primary text-white' : 'hover:bg-primary-light hover:text-primary-dark'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" /></svg>
                  إدارة الأكواد
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center py-2 px-3 rounded-lg font-cairo transition duration-200 ${activeTab === 'settings' ? 'bg-primary text-white' : 'hover:bg-primary-light hover:text-primary-dark'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  الإعدادات
                </button>
              </li>
            </ul>
            <div className="border-t border-gray-700 mt-8 pt-4">
              <button className="w-full flex items-center py-2 px-3 rounded-lg font-cairo text-red-400 hover:bg-red-500 hover:text-white transition duration-200">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                تسجيل الخروج
              </button>
            </div>
          </nav>
        </aside>

        {/* المحتوى الرئيسي للوحة التحكم */}
        <main className="flex-1 p-6">
          {/* نظرة عامة */}
          {activeTab === 'dashboard' && (
            <div>
              <h2 className="text-2xl font-cairo font-bold text-neutral-dark mb-6">نظرة عامة</h2>
              {/* الإحصائيات */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="font-cairo text-neutral mb-1">إجمالي المبيعات</h3>
                  <p className="text-2xl font-cairo font-bold text-primary-dark">{stats.totalSales.toFixed(2)} ريال</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="font-cairo text-neutral mb-1">إجمالي الطلبات</h3>
                  <p className="text-2xl font-cairo font-bold text-primary-dark">{stats.totalOrders}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="font-cairo text-neutral mb-1">إجمالي المستخدمين</h3>
                  <p className="text-2xl font-cairo font-bold text-primary-dark">{stats.totalUsers}</p>
                </div>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h3 className="font-cairo text-neutral mb-1">إجمالي المنتجات</h3>
                  <p className="text-2xl font-cairo font-bold text-primary-dark">{stats.totalProducts}</p>
                </div>
              </div>

              {/* الطلبات الأخيرة */}
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="p-4 border-b">
                  <h3 className="text-xl font-cairo font-bold text-neutral-dark">الطلبات الأخيرة</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">رقم الطلب</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">العميل</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">التاريخ</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">المجموع</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الحالة</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {recentOrders.map((order) => (
                        <tr key={order.id} className="hover:bg-gray-50">
                          <td className="py-3 px-4 font-cairo">{order.id}</td>
                          <td className="py-3 px-4 font-cairo">{order.customer}</td>
                          <td className="py-3 px-4 font-tajawal">{formatDate(order.date)}</td>
                          <td className="py-3 px-4 font-cairo">{order.total.toFixed(2)} ريال</td>
                          <td className="py-3 px-4">
                            <span className={`inline-block py-1 px-2 rounded-full text-xs font-cairo ${order.status === 'completed' ? 'bg-green-100 text-green-800' : order.status === 'processing' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {getStatusText(order.status)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* إدارة المنتجات */}
          {activeTab === 'products' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-cairo font-bold text-neutral-dark">إدارة المنتجات</h2>
                <button className="bg-primary hover:bg-primary-dark text-white font-cairo py-2 px-4 rounded-lg transition duration-300">
                  إضافة منتج جديد
                </button>
              </div>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">#</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">اسم المنتج</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">السعر</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">المخزون</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">التصنيف</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {products.map((product, index) => (
                        <tr key={product.id} className="hover:bg-gray-50">
                          <td className="py-3 px-4 font-cairo">{index + 1}</td>
                          <td className="py-3 px-4 font-cairo">{product.name}</td>
                          <td className="py-3 px-4 font-cairo">{product.price.toFixed(2)} ريال</td>
                          <td className="py-3 px-4 font-cairo">{product.stock}</td>
                          <td className="py-3 px-4 font-cairo">{product.category}</td>
                          <td className="py-3 px-4 space-x-reverse space-x-2">
                            <button className="text-blue-600 hover:text-blue-800 font-cairo text-sm">تعديل</button>
                            <button className="text-red-600 hover:text-red-800 font-cairo text-sm">حذف</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* إدارة الطلبات */}
          {activeTab === 'orders' && (
             <div>
              <h2 className="text-2xl font-cairo font-bold text-neutral-dark mb-6">إدارة الطلبات</h2>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                 <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">رقم الطلب</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">العميل</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">التاريخ</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">المجموع</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الحالة</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {recentOrders.concat(recentOrders).map((order) => ( // Placeholder: duplicate orders for more data
                        <tr key={order.id} className="hover:bg-gray-50">
                          <td className="py-3 px-4 font-cairo">{order.id}</td>
                          <td className="py-3 px-4 font-cairo">{order.customer}</td>
                          <td className="py-3 px-4 font-tajawal">{formatDate(order.date)}</td>
                          <td className="py-3 px-4 font-cairo">{order.total.toFixed(2)} ريال</td>
                          <td className="py-3 px-4">
                            <span className={`inline-block py-1 px-2 rounded-full text-xs font-cairo ${order.status === 'completed' ? 'bg-green-100 text-green-800' : order.status === 'processing' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {getStatusText(order.status)}
                            </span>
                          </td>
                           <td className="py-3 px-4 space-x-reverse space-x-2">
                            <button className="text-blue-600 hover:text-blue-800 font-cairo text-sm">عرض</button>
                            <button className="text-green-600 hover:text-green-800 font-cairo text-sm">تحديث الحالة</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* إدارة المستخدمين */}
          {activeTab === 'users' && (
            <div>
              <h2 className="text-2xl font-cairo font-bold text-neutral-dark mb-6">إدارة المستخدمين</h2>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">#</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الاسم</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">البريد الإلكتروني</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">تاريخ الانضمام</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {users.map((user, index) => (
                        <tr key={user.id} className="hover:bg-gray-50">
                          <td className="py-3 px-4 font-cairo">{index + 1}</td>
                          <td className="py-3 px-4 font-cairo">{user.name}</td>
                          <td className="py-3 px-4 font-tajawal">{user.email}</td>
                          <td className="py-3 px-4 font-tajawal">{user.joinDate}</td>
                          <td className="py-3 px-4 space-x-reverse space-x-2">
                            <button className="text-blue-600 hover:text-blue-800 font-cairo text-sm">عرض</button>
                            <button className="text-red-600 hover:text-red-800 font-cairo text-sm">حظر</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* إدارة الأكواد */}
          {activeTab === 'codes' && (
            <div>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-cairo font-bold text-neutral-dark">إدارة الأكواد الرقمية</h2>
                <button className="bg-primary hover:bg-primary-dark text-white font-cairo py-2 px-4 rounded-lg transition duration-300">
                  إضافة أكواد جديدة
                </button>
              </div>
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">#</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">المنتج</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الكود</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الحالة</th>
                        <th className="py-3 px-4 text-right font-cairo text-neutral-dark">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {codes.map((code, index) => (
                        <tr key={code.id} className="hover:bg-gray-50">
                          <td className="py-3 px-4 font-cairo">{index + 1}</td>
                          <td className="py-3 px-4 font-cairo">{code.product}</td>
                          <td className="py-3 px-4 font-mono text-sm">{code.code}</td>
                          <td className="py-3 px-4">
                             <span className={`inline-block py-1 px-2 rounded-full text-xs font-cairo ${code.status === 'available' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                              {getCodeStatusText(code.status)}
                            </span>
                          </td>
                          <td className="py-3 px-4 space-x-reverse space-x-2">
                            <button className="text-red-600 hover:text-red-800 font-cairo text-sm">حذف</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* الإعدادات */}
          {activeTab === 'settings' && (
            <div>
              <h2 className="text-2xl font-cairo font-bold text-neutral-dark mb-6">الإعدادات</h2>
              <div className="bg-white rounded-lg shadow-md p-6">
                <p className="font-tajawal text-neutral">هنا ستكون إعدادات المتجر العامة (مثل اسم المتجر، الشعار، طرق الدفع، إعدادات الشحن إذا كانت مطلوبة، إلخ)</p>
                {/* Placeholder for settings form */}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

